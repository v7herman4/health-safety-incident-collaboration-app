For Installation instructions, Please refer Collaboration Apps installation guide available at below link: 

https://aka.ms/AAhbyy5